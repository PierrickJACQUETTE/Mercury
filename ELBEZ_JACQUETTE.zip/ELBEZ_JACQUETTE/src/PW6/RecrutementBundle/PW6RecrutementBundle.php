<?php

namespace PW6\RecrutementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PW6RecrutementBundle extends Bundle
{
}
