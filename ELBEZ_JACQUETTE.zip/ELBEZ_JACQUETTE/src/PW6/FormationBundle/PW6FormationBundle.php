<?php

namespace PW6\FormationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PW6FormationBundle extends Bundle
{
}
