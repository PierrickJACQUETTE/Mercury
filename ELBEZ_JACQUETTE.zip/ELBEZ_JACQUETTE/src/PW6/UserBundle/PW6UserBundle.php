<?php

namespace PW6\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PW6UserBundle extends Bundle
{
}
