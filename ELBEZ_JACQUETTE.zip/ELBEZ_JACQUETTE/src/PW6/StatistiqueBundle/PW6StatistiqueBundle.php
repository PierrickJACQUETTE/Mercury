<?php

namespace PW6\StatistiqueBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PW6StatistiqueBundle extends Bundle
{
}
